public class DLinkList implements MyList {

    private Node head;
    private Node tail;
    private int size;

    public DLinkList() {
        size = 0;
    }


    private class Node {
        Object data;
        Node prev;
        Node next;


        private Node (Object data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    //insert 'item' at 'index'. Must rearrange pointers.
    public boolean insert(int index, Object item){
        //declare newNode and set next and prev to null
        Node newNode = new Node(item);
        newNode.next = null;
        newNode.prev = null;

        //Exception when argument's index does not match the size of the list
        if (index < 0 || index > this.size) {
            System.out.println("Error: Index out of Bound");
            return false;
        }

        // when nothing is in the list
        else if (head == null) {
            append(item);
            return true;
        }

        // t when user inputs size as the index
        else if (index == size) {
            append(item);
            return true;
        }

        // when the list is not empty and the user inputs 0 as index
        else if ((head != null) && (index == 0)) {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }

        // inserting the element in the list
        else {
            //declare temporary Node and assign it to the head
            Node temp = head;
            //loop until the index
            for (int i = 0; i < index - 1; i++) {
                temp = temp.next;
            }

            // set the pointers of the new node
            newNode.next = temp.next;
            newNode.prev = temp;
            temp.next = newNode;
            //increment the size
            size++;
        }
        return true;
    }



    //insert 'item' at the end of the list.
    public boolean append(Object item){
        Node n = new Node(item);

        // if there's nothing inside the list, set the new node to head and tail
        if(head == null) {
            head = n;
            tail = n;
            size++;
        }

        // appends the new element to the back of the list
        else {
            tail.next = n;
            n.prev = tail;
            tail = n;
            size++;
        }
        return true;
    }

    //clear the entire list.
    public void clear(){
        Node n = head;
        //when there is nothing in the list
        if (n == null) {
            System.out.println("Error: No element inside the list");
        }

        // sets all the pointers and element to null until the list is empty
        while(n != null) {
            Node temp = n.next;
            n.next = null;
            n.prev = null;
            n = temp;
        }
        // sets size into 0
        size = 0;
    }

    // return true if list is empty or false otherwise.
    public boolean isEmpty(){
        if (size == 0) {
            System.out.println("It is Empty");
            return true;
        }
        else {
            System.out.println("It is Not Empty");
            return false;
        }
    }

    // return the size of the list, else -1.
    public int size(){
        if(this.size != 0){
            return this.size;
        }
        return -1;
    }

    // replaces the element at 'index' with 'item'.
    public boolean replace(int index, Object item){
    //declare new node and set the pointers to null
        Node newNode = new Node(item);
        newNode.next = null;
        newNode.prev = null;

        //when the argument's index doesn't match the size of the list
        if (index < 0 || index > this.size) {
            System.out.println("Error: Index out of Bound");
            return false;
        }

        // when the list is empty
        else if (head == null) {
            append(item);
            return true;
        }

        // when user inputs size as an index
        else if (index == size) {
            append(item);
            return true;
        }

        // replaces the element inside the list
        else {
            //declare the current node and assign it to head
            Node curr = head;
            //loop until the index
            for (int i = 0; i < index; i++) {
                curr = curr.next;
            }
            //you don't have to change the pointers. Just change the data inside the Node
            curr.data = newNode.data;
        }

        return true;
    }

    // removes the element at 'index'.
    public boolean remove(int index){
//Exception when there's nothing inside the list
        if(head == null) {
            System.out.println("Error: No element inside the list");
            return false;
        }
        // else statement for replacement
        else {
            //set the node to head
            Node curr = head;

            //loop until the index
            for(int i = 0; i < index; i++){
                curr = curr.next;
                // if user inputs the index that is out of bound, exception statement executes
                if (curr == null) {
                    System.out.println("Error: Current value is null. Please check your index again");
                    return false;
                }
            }

            // if statement when current node is the head of the list
            if(curr == head) {
                head = curr.next;
            }

            // replaces the element inside the list
            else {
                if (curr.prev != null) {
                    curr.prev.next = curr.next;
                }
                if (curr.next != null) {
                    curr.next.prev = curr.prev;
                }
                if (curr == tail) {
                    tail = tail.prev;
                }
            }
            // decrement the size of the list
            size--;
        }
        return true;
    }

    // return the element at 'index', but don't remove the item.
    public Object get(int index){
        Node n = head;
        // when the index is out of bounds
        if (index >= this.size) {
            System.out.println("Error: Index out of Bounds");
            return null;
        }


        for (int i = 0; i < index; i++) {
            n = n.next;
        }
        return n.data;
    }

}







