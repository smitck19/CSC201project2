/**
 * Master theorem:
 * a : 2
 * b : 2
 * c : n
 * T(n) = theta(nlogn)
 */



import java.util.*;
public class quick {
    public static void my_quicksort(int[] array){
        quicksort_helper(array, 0, array.length-1);
    }


    private static void quicksort_helper(int [] array, int low, int high){
        if(low < high){
            int partInt = partition(array, low, high);
            quicksort_helper(array, partInt+1, high);
            quicksort_helper(array, low, partInt-1);
        }
    }

    private static int partition(int[] array, int low, int high){
        int pivot = array[high];

        // Index of smaller element and
        // indicates the right position
        // of pivot found so far
        int i = (low - 1);

        for(int j = low; j <= high - 1; j++)
        {

            // If current element is greater than or equal to the pivot
            if (array[j] >= pivot) {

                i++;
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
        int temp = array[i+1];
        array[i] = array[high];
        array[high] = temp;
        return (i + 1);
    }


public static void main(String [] args){
        Random rand = new Random();
        int len = 10;
        int [] arr = new int[len];
        for(int i = 0; i < len; i++){
            arr[i] = rand.nextInt(10);
        }
        my_quicksort(arr);
    for (int i = 0; i <len; i++) {
        System.out.println(arr[i] + " ");
    }


}






}
