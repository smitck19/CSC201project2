import java.util.*;
public class WeirdQueue {



    private static class MyQueue<E> {
        Stack<E> newST = new Stack<E>();
        Stack<E> oldST = new Stack<E>();

        // enqueue method
        public void enqueue(E item) {
            this.newST.push(item);
        }

        // dequeue method
        public E dequeue() {
            // push the object that is popped out of the list
            while (!newST.isEmpty()) {
                oldST.push(newST.pop());
            }
            if (oldST.isEmpty()) {
                System.out.println("Error: No element inside the list");
                return null;
            }
            return oldST.pop();
        }
    }




    public static void main (String[] args) {
        MyQueue<Integer> q = new MyQueue<Integer>();
        q.enqueue(12);
        q.enqueue(13);
        q.enqueue(23);
        q.enqueue(36);
        q.enqueue(45);

        System.out.println(q.dequeue());
        System.out.println(q.dequeue());
        System.out.println(q.dequeue());
        System.out.println(q.dequeue());
        System.out.println(q.dequeue());
        System.out.println(q.dequeue());

    }

}