
public class BST{

    private class TreeNode {
        int data;
        TreeNode left;
        TreeNode right;

        private TreeNode (int item) {
            data = item;
            left = null;
            right = null;
        }
    }

    public TreeNode ArrayToTree (int[] array, int low, int high) {
        if (low > high) {
            return null;
        }

        // declare the mid-point
        int mid = (low + high) / 2;
        TreeNode n = new TreeNode(array[mid]);
        // recursive method to set the left side of the binary tree
        n.left = ArrayToTree(array, low, mid - 1);
        // recursive method to set the right side of the binary tree
        n.right = ArrayToTree(array, mid + 1, high);

        return n;
    }
    // method for post order traversal
    public void postOrder(TreeNode node) {
        if (node == null) {
            return;
        }
        postOrder(node.left);
        postOrder(node.right);
        System.out.print(node.data + " ");
    }

    // method for pre order traversal
    public void preOrder(TreeNode node) {
        if (node == null) {
            return;
        }

        System.out.print(node.data + " ");
        preOrder(node.left);
        preOrder(node.right);
    }

    // method for in order traversal
    public void inOrder(TreeNode node) {
        if (node == null) {
            return;
        }

        inOrder(node.left);
        System.out.print(node.data + " ");
        inOrder(node.right);
    }


}